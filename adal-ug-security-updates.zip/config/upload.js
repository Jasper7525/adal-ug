import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import multer from 'multer';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadDir = path.join(__dirname, '..', 'public', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const allowedMimeTypes = new Set(['image/jpeg', 'image/png', 'image/webp']);
const extensionFor = (mime) => ({ 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' }[mime] || '');

// Durable media storage: when S3_BUCKET is set, uploaded images go to any
// S3-compatible bucket (AWS S3, Cloudflare R2, Backblaze B2, DigitalOcean
// Spaces, Supabase Storage, ...), which survives restarts and redeploys.
// Without it, files stay on local disk under public/uploads — fine for a
// single VPS with a persistent disk, but most PaaS hosts (Render, Railway,
// Heroku-style) wipe the app filesystem on every deploy, so images uploaded
// through the admin panel would silently disappear on the next release.
export const durableStorageEnabled = Boolean(process.env.S3_BUCKET);

if (!durableStorageEnabled) {
  console.warn('[uploads] S3_BUCKET is not set — product/media images are stored on local disk. This is NOT durable on most hosting platforms: a redeploy or container restart can wipe public/uploads. Set S3_BUCKET (and related S3_* variables) for durable storage, or make sure your host mounts a persistent volume at public/uploads.');
}

let s3ClientPromise = null;
async function getS3Client() {
  if (!s3ClientPromise) {
    s3ClientPromise = import('@aws-sdk/client-s3').then(({ S3Client }) => new S3Client({
      region: process.env.S3_REGION || 'auto',
      endpoint: process.env.S3_ENDPOINT || undefined,
      forcePathStyle: Boolean(process.env.S3_ENDPOINT),
      credentials: process.env.S3_ACCESS_KEY_ID
        ? { accessKeyId: process.env.S3_ACCESS_KEY_ID, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY }
        : undefined,
    }));
  }
  return s3ClientPromise;
}

function safeFileName(originalname, mime) {
  const extension = path.extname(originalname || '').toLowerCase() || extensionFor(mime);
  const safeBase = path.basename(originalname || 'image', extension).replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 80) || 'image';
  return `${Date.now()}-${crypto.randomBytes(4).toString('hex')}-${safeBase}${extension}`;
}

const storage = durableStorageEnabled
  ? multer.memoryStorage()
  : multer.diskStorage({
      destination: (_req, _file, cb) => cb(null, uploadDir),
      filename: (_req, file, cb) => cb(null, safeFileName(file.originalname, file.mimetype)),
    });

export const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!allowedMimeTypes.has(file.mimetype)) return cb(new Error('Only JPEG, PNG and WebP images are allowed.'));
    cb(null, true);
  },
});

// Call this after multer has validated+captured the file (req.file) to get
// back a public URL, regardless of which backend is active.
export async function persistUploadedFile(file) {
  if (!durableStorageEnabled) return `/uploads/${file.filename}`;

  const { PutObjectCommand } = await import('@aws-sdk/client-s3');
  const client = await getS3Client();
  const prefix = process.env.S3_PREFIX ? `${process.env.S3_PREFIX.replace(/\/$/, '')}/` : '';
  const key = `${prefix}${safeFileName(file.originalname, file.mimetype)}`;

  await client.send(new PutObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: key,
    Body: file.buffer,
    ContentType: file.mimetype,
    ACL: process.env.S3_ACL || 'public-read',
  }));

  if (process.env.S3_PUBLIC_URL_BASE) return `${process.env.S3_PUBLIC_URL_BASE.replace(/\/$/, '')}/${key}`;
  if (process.env.S3_ENDPOINT) {
    const host = process.env.S3_ENDPOINT.replace(/^https?:\/\//, '').replace(/\/$/, '');
    return `https://${process.env.S3_BUCKET}.${host}/${key}`;
  }
  return `https://${process.env.S3_BUCKET}.s3.${process.env.S3_REGION || 'us-east-1'}.amazonaws.com/${key}`;
}

// Best-effort delete, mirroring persistUploadedFile's backend choice. Only
// ever acts on URLs this app generated (local /uploads/... paths, or keys
// under the configured bucket) — never an arbitrary caller-supplied URL.
export async function removeUploadedFile(url) {
  if (!url) return;
  if (!durableStorageEnabled) {
    if (!String(url).startsWith('/uploads/')) return;
    const file = path.join(uploadDir, path.basename(url));
    if (fs.existsSync(file)) fs.unlinkSync(file);
    return;
  }
  try {
    const { DeleteObjectCommand } = await import('@aws-sdk/client-s3');
    const client = await getS3Client();
    const key = String(url).split('/').pop();
    const prefix = process.env.S3_PREFIX ? `${process.env.S3_PREFIX.replace(/\/$/, '')}/` : '';
    await client.send(new DeleteObjectCommand({ Bucket: process.env.S3_BUCKET, Key: `${prefix}${key}` }));
  } catch (error) {
    console.error('[uploads] Failed to delete object from durable storage:', error.message);
  }
}

export { uploadDir };
