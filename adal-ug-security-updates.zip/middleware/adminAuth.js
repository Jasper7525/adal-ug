import { resolveSession } from '../lib/adminStore.js';

export async function requireAdmin(req, res, next) {
  const incomingToken = req.headers['x-admin-token'] || req.headers.authorization?.replace('Bearer ', '');
  const session = incomingToken ? await resolveSession(req.app, incomingToken) : null;

  if (!session) return res.status(401).json({ message: 'Admin authentication required.' });

  req.admin = session;
  req.adminToken = incomingToken;
  next();
}
