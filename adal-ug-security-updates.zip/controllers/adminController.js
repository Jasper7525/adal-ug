import { query, databaseEnabled } from '../db/postgres.js';
import { verifyAdminCredentials, changeAdminPassword, createSession, destroySession } from '../lib/adminStore.js';

export async function login(req, res) {
  try {
    const { username, password, rememberMe } = req.body || {};

    if (process.env.NODE_ENV === 'production' && !databaseEnabled) {
      return res.status(503).json({
        success: false,
        message: 'The database is not configured, so administrator accounts cannot be verified. Set DATABASE_URL in the production environment.',
      });
    }
    if (!username || !password) {
      return res.status(400).json({ success: false, message: 'Username and password are required.' });
    }

    const admin = await verifyAdminCredentials(String(username).trim(), String(password));
    if (!admin) return res.status(401).json({ success: false, message: 'Invalid administrator credentials.' });

    const { token, expiresIn, rememberMe: remembered } = await createSession(req.app, admin, Boolean(rememberMe));
    return res.json({ success: true, token, expiresIn, rememberMe: remembered });
  } catch (error) {
    console.error('Admin login failed:', error);
    return res.status(500).json({
      success: false,
      message: process.env.NODE_ENV === 'production'
        ? 'Administrator login failed on the server. Check the deployment logs.'
        : error?.message || 'Administrator login failed.',
    });
  }
}

export async function logout(req, res) {
  await destroySession(req.app, req.adminToken);
  return res.json({ success: true });
}

// Lets a signed-in admin set a new password without ever hardcoding one or
// redeploying the app. Requires the current password and enforces the same
// strength policy used when the account is first created.
export async function changePassword(req, res) {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body || {};
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ success: false, message: 'Current and new password are required.' });
    }
    if (confirmPassword !== undefined && confirmPassword !== newPassword) {
      return res.status(400).json({ success: false, message: 'New password and confirmation do not match.' });
    }
    await changeAdminPassword(req.admin.adminId, currentPassword, newPassword);
    return res.json({ success: true, message: 'Password updated. Use the new password next time you sign in.' });
  } catch (error) {
    return res.status(error.status || 500).json({ success: false, message: error.message || 'Failed to change password.' });
  }
}

export async function getVisitors(req, res) {
  try {
    if (!databaseEnabled) return res.json((req.app.locals.visitorStore || []).slice(0, 200));
    const result = await query(`SELECT id, method, path, ip, user_agent, referrer, status_code, visited_at FROM adal_visits ORDER BY visited_at DESC LIMIT 200`);
    return res.json(result.rows);
  } catch (error) { return res.status(500).json({ message: error.message }); }
}
